package Main;

import java.awt.EventQueue;
import javax.swing.JFrame;

public class PacBoy extends JFrame {

    public PacBoy() {

        initUI();
    }

    private void initUI() {

        add(new Map());

        setTitle("PacBoy");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(380, 420);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {

        EventQueue.invokeLater(() -> {

            var ex = new PacBoy();
            ex.setVisible(true);
        });
    }
}
